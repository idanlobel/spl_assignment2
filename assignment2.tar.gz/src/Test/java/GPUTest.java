


class GPUTest {

//    private static GPU gpu;
//    private Model model;
//    private Data d;
//
//    @Before
//    public void setup() throws Exception{
//        d=new Data(null,10000);
//        model=new Model(d);
//        gpu=new GPU(model,null);
//    }
//
//
//    @Test
//    void test_makebatch() {
//        d=new Data(null,10000);
//        model=new Model(d);
//        gpu=new GPU(model,null);
//        this.gpu.makebatch();
//        assertNotEquals(null,okay);
//
//    }
//
//
//    @Test
//    void test_update_data_proccessed_model()
//    {
//        d=new Data(null,10000);
//        model=new Model(d);
//        gpu=new GPU(model,null);
//        int proccesed_after=this.model.getdata().get_processed()+1000;
//        this.gpu.update_data_proccessed_model();
//        assertEquals(proccesed_after,this.model.getdata().get_processed());
//    }


}
