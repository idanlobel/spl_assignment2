import bgu.spl.mics.Future;
import bgu.spl.mics.application.objects.Data;
import bgu.spl.mics.application.objects.Model;

class FutureTest {


    private static Future<Model> future;
    private Model result;
    private Data d;
//
//    @Before
//    public void setup() throws Exception{
//        d=new Data(null,10000);
//        future=new Future();
//        result=new Model(d);
//    }
//
//
//    @Test
//    void test_isDone() {
//        future=new Future();
//        assertEquals(false,future.isDone());
//        future.resolve(null);
//        assertEquals(true,future.isDone());
//    }
//
//
//    @Test
//    void test_resolve() {
//        //future=new Future();//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ wWWTTTTFFFFF??!??!!?
//        future.resolve(result);
//        assertEquals(result,future.get());
//
//    }
//    @Test
//    void test_get_time() {
//        future.get(10, TimeUnit.SECONDS);
//        assertEquals(false,future.isDone());
//        future.resolve(null);
//        assertEquals(true,future.isDone());
//    }




}
