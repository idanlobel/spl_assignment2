package bgu.spl.mics.application.broadcasts;

import bgu.spl.mics.Broadcast;

public class ConferencePublicationBroadcasts implements Broadcast {
}
