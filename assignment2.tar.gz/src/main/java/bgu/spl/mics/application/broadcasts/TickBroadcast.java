package bgu.spl.mics.application.broadcasts;

import bgu.spl.mics.Broadcast;

public class TickBroadcast implements Broadcast {
}
